const readline = require('readline').createInterface({

  input: process.stdin,
  output: process.stdout
});

readline.question('1부터 9 사이의 숫자를 입력하세요: ', (input) => {
  const dan = parseInt(input, 10);

  if (dan >= 1 && dan <= 9) {
    console.log(`구구단 ${dan}단`);
    for (let i = 1; i <= 9; i++) {
      console.log(`${dan} x ${i} = ${dan * i}`);
    }
  } else {
    console.log('1부터 9 사이의 숫자를 입력해주세요.');
  }

  readline.close();
});
