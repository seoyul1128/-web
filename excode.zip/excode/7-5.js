let str = "javascript";
let stack = [];

for (let i = 0; i < str.length; i++) {
    stack.push(str[i]);
}

let reversed = "";
while (stack.length > 0) {
    reversed += stack.pop();
}

console.log(reversed);